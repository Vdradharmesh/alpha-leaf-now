<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>

 <body style="background-color:green;">


<h1>Resistration Successful</h1>
<h1>Please re-login</h1>
</body>
</html>