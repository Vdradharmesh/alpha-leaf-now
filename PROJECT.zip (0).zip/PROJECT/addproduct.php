<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>product page</title>
</head>
<body>

<table border="1">
<tr align="center">
<td>
<img src="product6.jpg" width="200" height="230"><br>
crocosmia lucifer<br>
price Rs:200<br>
Crocosmia Lucifer blooms in summer with brilliant, hummingbird-attracting scarlet-red flowers on arching stems. Crocosmia Lucifer bulbs (corms) will do best in rich, moisture-retentive soils, in full or partial sun. Perennial in zones 5-9.
<H2><button onclick="document.location='addproduct.php'">Add To Cart</button> </H2>
<br></td>

</tr>



<table border="1">
<tr align="center">
<td>
<img src="product7.jpg" width="200" height="230"><br>
bessera elegans<br>
price Rs:300<br>
Bessera is a genus of Mexican plants in the cluster lily subfamily within the asparagus family. It is a small genus of 3 known species of mostly herbaceous flowering plants with corms. Thin leaves spread out on the ground and wiry stems produce fuchsia-like flowers; prefers well-drained, sandy soil. Best grown in a pot.
<H2><button onclick="document.location='addproduct.php'">Add To Cart</button> </H2>
<br></td>

</tr>




<table border="1">
<tr align="center">
<td>
<img src="product8.jpg" width="200" height="230"><br>
freesia mixture<br>
price Rs:400<br>
Many gardeners love Freesia for its sweet fragrance and our Double Freesia Mix does not disappoint! This mix comes with 25 freesia bulbs that will produce gorgeous, double flowers doused in the sweet, captivating fragrance that we all love. Hardy in zones 9-10, considered an annual in all other zones. (Freesia)
<H2><button onclick="document.location='addproduct.php'">Add To Cart</button> </H2>
<br></td>

</tr>


</table>





</body>
</html>