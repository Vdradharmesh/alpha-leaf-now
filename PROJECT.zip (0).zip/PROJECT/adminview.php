<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login Successful</title>
<link rel="stylesheet" href="adminview.css">
</head>
<body>

 <div class="card">
  
  
  <H2><button onclick="document.location='userlogindetails.php'">View login details</button> </H2>
</div> 


 <div class="card">
  
  
  <H2><button onclick="document.location='process.php'">View order details</button> </H2>
</div> 

<div class="card">
  
  <H2><button onclick="document.location='addtype.php'">Add Products</button> </H2>
</div> 


<div class="card">
  
  <H2><button onclick="document.location='deletecode.php'">Delete Products</button> </H2>
</div> 

<br><br>

</body>
</html>