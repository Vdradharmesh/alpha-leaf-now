<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>WELCOME TO LEAF NOW</title>
<link rel="stylesheet" href="welcome.css">

</head>

<body>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<p><b>WELCOME TO LEAF NOW </b></p>
  
 <H1><button onclick="document.location='index.html'">ADMIN LOGIN</button> </H1>
  
 <H1><button onclick="document.location='form1.html'">USER LOGIN</button> </H1>

 <br><br><br><br><br><br>
</body>
</html>