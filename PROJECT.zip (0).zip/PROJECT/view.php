<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Views</title>
<link rel="stylesheet" href="view.css">

</head>

<body>
<br><br><br><br><br><br><br><br><br>
<p><b>WELCOME TO LEAF NOW</b></p>
  
 <H1><button onclick="document.location='description.php'">LEAF NOW Special</button> </H1>
  
 <H1><button onclick="document.location='index.php'">Always available</button> </H1>

 <br><br><br><br><br><br><br><br>
</body>
</html>