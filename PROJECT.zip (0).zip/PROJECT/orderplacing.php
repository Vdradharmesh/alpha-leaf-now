<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Order Placing</title>
<link rel = "stylesheet" type = "text/css" href = "orderplacing.css">
</head>
<body>

<br> 
Address  
<br>  
<textarea cols="80" rows="5" value="address">  
</textarea>  
<br> <br>  

<br>  
<br>  
   
Phone :  
</label>  
<input type="text" name="country code"  value="+91" size="2"/>   
<input type="text" name="phone" size="10"/> <br> <br>  

<H2><button onclick="document.location='ordered.php'">Place order</button> </H2>

</body>
</html>