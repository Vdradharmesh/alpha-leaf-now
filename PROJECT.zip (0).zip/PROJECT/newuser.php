<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>




<body>
<body bgcolor="Lightskyblue">  
<br>  
<br>  
<form>  
  
<label> Firstname </label>         
<input type="text" name="firstname" size="15"/> <br> <br>  
<label> Middlename: </label>     
<input type="text" name="middlename" size="15"/> <br> <br>  
<label> Lastname: </label>         
<input type="text" name="lastname" size="15"/> <br> <br>  
  
<label>   
GENDER :  
</label>   
<select>  
<option value="Course">MALE</option>  
<option value="BCA">FEMALE</option>  
<option value="BBA">OTHER</option>  
 
</select>  
  
<br>  
<br>  
   
Phone :  
</label>  
<input type="text" name="country code"  value="+91" size="2"/>   
<input type="text" name="phone" size="10"/> <br> <br>  
Address  
<br>  
<textarea cols="80" rows="5" value="address">  
</textarea>  
<br> <br>  
Email:  
<input type="email" id="email" name="email"/> <br>    
<br> <br>  
Password:  
<input type="Password" id="pass" name="pass"> <br>   
<br> <br>  
Re-type password:  
<input type="Password" id="repass" name="repass"> <br> <br>  
 
    
    <button type="reset" value="Reset">Reset</button>
</form> 
   
 

  
   

</body>
    
    
    
    
    
    
    
  
  </div>

  <div class="container signin">
    <p>Already have an account?  <H2><button onclick="document.location='userconnection.php'"> Login</button> </H2></p>
    
    
    
    </head>  



 <style>
body {
  background-image: url('newuser.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style> 


</body>
</html>