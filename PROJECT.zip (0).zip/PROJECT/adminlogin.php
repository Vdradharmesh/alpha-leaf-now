<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>


<form>
        <div class="login-box">
            <h1>Login</h1>
 
 <label> Adminname </label>         
<input type="text" name="firstname" size="15"/> <br> <br>  
 
  
  <br> <br>  
Password:  
<input type="Password" id="pass" name="pass"> <br>   
<br> <br>
 
            
                     
                      
                      
                        <button type="reset" value="Reset">Reset</button>
        </div>
        
        
        
        
        
        
    
    </form>
    
    <H2><button onclick="document.location='description.php'">login</button> </H2>
     <style>
body {
  background-image: url('adminlogin.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style> 

</body>
</html>