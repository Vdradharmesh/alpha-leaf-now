<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Ordered Successfully</title>
<link rel = "stylesheet" type = "text/css" href = "ordered.css">
</head>
<body>
<br><br><br><br>
<h4>Your order will deliver soon and payment will be Cash on Delivery</h4>
<h4>Bill will be issued with Order</h4>
<h4>Thank You for ordering!!</h4>
<h4>Visit Again:) </h4>

<h4>For any info call:</h4>
<h4>DHANUSH G:9620932319</h4>
<h4>JOSHEELA : 8139901104</h4>
<br><br><br><br><br>
</body>
</html>