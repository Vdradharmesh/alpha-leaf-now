<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>LEAF NOW Specials</title>
<link rel = "stylesheet" type = "text/css" href = "description.css">
</head>
<body>
<br><br>
 <h1 style="text-align:center;">LEAF NOW Specials</h1>

 

 
  <input type="image" src="anthurium.jpg" alt="Submit" width="560" height="560">
   
<H2><button onclick="document.location='anthurium.php'">View Details</button> </H2><br><br>



<input type="image" src="areca.jpg" alt="Submit" width="560" height="560" >
   
   <H2><button onclick="document.location='areca.php'">View Details</button> </H2><br><br>
   
   
   
    <input type="image" src="cactus.jpg" alt="Submit" width="560" height="560">
     
    <H2><button onclick="document.location='cactus.php'">View Details</button> </H2><br><br>


    
    
    <input type="image" src="daisy.jpg" alt="Submit" width="560" height="560">
     
    <H2><button onclick="document.location='daisy.php'">View Details</button> </H2><br><br>


	
	
     <input type="image" src="emb.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='emb.php'">View Details</button> </H2><br><br>




    <input type="image" src="fejka.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='fejka.php'">View Details</button> </H2><br><br>




    <input type="image" src="inch.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='inch.php'">View Details</button> </H2><br><br>



    <input type="image" src="tea.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='tea.php'">View Details</button> </H2><br><br>




    <input type="image" src="rose.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='roses.php'">View Details</button> </H2><br><br>




    <input type="image" src="money.jpg" alt="Submit" width="560" height="560">
      
    <H2><button onclick="document.location='money.php'">View Details</button> </H2><br><br>
    
    
    
</body>
</html>